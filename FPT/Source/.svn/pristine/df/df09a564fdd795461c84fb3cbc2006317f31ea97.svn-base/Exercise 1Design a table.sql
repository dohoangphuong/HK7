CREATE DATABASE FresherTrainingManagement
USE FresherTrainingManagement
GO

--Q1:Create the tables (with the most appropriate/economic field/column constraints & types).
CREATE TABLE TRAINEE
(
	TraineeID	INT IDENTITY(1,1) PRIMARY KEY,
	Full_Name	VARCHAR(40),
	Birth_Date	SMALLDATETIME,
	Gender VARCHAR(8) NOT NULL CHECK (Gender IN('male','female','unknown')),
	ET_IQ TINYINT CHECK (ET_IQ >= 0 AND ET_IQ <= 20),
	ET_Gmath TINYINT CHECK (ET_Gmath >= 0 AND ET_Gmath <= 20),
	ET_English TINYINT CHECK (ET_English >= 0 AND ET_English <= 50),
	Training_Class VARCHAR(40),
	Evaluation_Notes VARCHAR(MAX)
)

--Q2:Change the table TRAINEE to add one more field named Fsoft_Account which is a not-null &unique field.
ALTER TABLE TRAINEE ADD Fsoft_Account varchar(20) NOT NULL;
ALTER TABLE TRAINEE ADD CONSTRAINT UQ_TRAINEE UNIQUE (Fsoft_Account);


--Q3: Add at least 10 records into created table.
SET DATEFORMAT DMY
INSERT INTO TRAINEE (Full_Name, Birth_Date, Gender, ET_IQ, ET_Gmath, ET_English, Training_Class, Evaluation_Notes, Fsoft_Account) VALUES  
					('Bill Gates','7/8/1989','female',7,9,8,'CL1','','Fsoft_Account1'),
					('Rupert Murdoch','9/3/1979','female',10,12,14,'CL2','','Fsoft_Account2'),
					('David Koch','5/8/1989','male',7,9,8,'CL1','','Fsoft_Account3'),
					('Michael Bloomberg','9/3/1979','female',10,12,14,'CL2','','Fsoft_Account4'),
					('Sheldon Adelson','4/8/1989','male',16,12,14,'CL2','','Fsoft_Account5'),
					('Warren Buffett','9/3/1979','female',7,9,8,'CL1','','Fsoft_Account6'),
					('George Soros','1/8/1989','unknown',10,12,14,'CL2','','Fsoft_Account7'),
					('Penny Pritzker','9/3/1979','unknown',7,9,8,'CL1','','Fsoft_Account8'),
					('Tom Steyer','5/8/1989','male',10,12,14,'CL2','','Fsoft_Account9'),
					('John Arnold','9/3/1979','female',7,9,8,'CL1','','Fsoft_Account10');
					
/*Q4:Create a VIEW which includes all the ET-passed trainees. One trainee is considered as ET-passed 
when he/she has the entry test points satisfied below criteria:
•	ET_IQ + ET_Gmath>=20
•	ET_IQ>=8
•	ET_Gmath>=8
•	ET_English>=18
*/
SELECT * 
FROM TRAINEE
WHERE ((ET_IQ + ET_Gmath>=20) AND (ET_IQ>=8) AND (ET_Gmath>=8) AND (ET_English>=18));

--Q5:Query the trainee who has the longest name, showing his/her age along with his/her basic information (as defined in the table)
SELECT *, DATEDIFF(YEAR, TRAINEE.Birth_Date, GETDATE())	AS AGE
FROM TRAINEE
WHERE LEN(Full_Name) IN(SELECT TOP 1 LEN(Full_Name) AS MAXLENGTH
						FROM TRAINEE
						ORDER BY LEN(Full_Name) DESC);