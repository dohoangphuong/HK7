USE AdventureWorks2012
GO

--Query 1
SELECT product.ProductID, product.Name, product.Color, product.ListPrice
FROM Production.Product product

--Query 2
SELECT product.ProductID, product.Name, product.Color, product.ListPrice
FROM Production.Product product
WHERE product.ListPrice <> 0

--Query 3
SELECT product.ProductID, product.Name, product.Color, product.ListPrice
FROM Production.Product product
WHERE product.Color is NULL

--Query 4
SELECT product.ProductID, product.Name, product.Color, product.ListPrice
FROM Production.Product product
WHERE product.Color is not NULL

--Query 5
SELECT product.ProductID, product.Name, product.Color, product.ListPrice
FROM Production.Product product
WHERE product.Color is not NULL AND product.ListPrice > 0

--Query 6
SELECT product.Name+':'+product.Color AS 'Name  And  Color'
FROM Production.Product product 
WHERE product.Color is not NULL

--Query 7
SELECT 'NAME:'+product.Name+'--COLOR:'+product.Color AS 'Name  And  Color'
FROM Production.Product product 
WHERE product.Color is not NULL

--Query 8
SELECT product.ProductID, product.Name
FROM Production.Product product 
WHERE product.ProductID BETWEEN 400 AND 500

--Query 9
SELECT product.ProductID, product.Name, product.Color
FROM Production.Product product
WHERE product.Color = 'Black' or product.Color = 'Blue' 

--Query 10
SELECT product.Name,product.ListPrice
FROM Production.Product product
WHERE product.Name LIKE 'S%' 
ORDER BY product.Name ASC

--Query 11
SELECT product.Name, product.ListPrice
FROM Production.Product product
WHERE product.Name LIKE 'A%' OR product.Name LIKE 'S%'
ORDER BY product.Name ASC

--Query 12
SELECT product.Name 
FROM Production.Product product
WHERE product.Name LIKE 'SPO%' and product.Name not in (	SELECT product.Name 
												FROM Production.Product product
												WHERE product.Name LIKE 'SPOK%') 
--Query 13
SELECT DISTINCT product.Color
FROM Production.Product product

--Query 14
SELECT DISTINCT product.ProductSubcategoryID, product.Color
FROM Production.Product product
WHERE product.Color is not NULL AND product.ProductSubcategoryID is not NULL

--Query 15
SELECT ProductSubCategoryID
      , LEFT([Name],35) AS [Name]
      , Color, ListPrice
FROM Production.Product
WHERE (Color IN ('Red','Black')
       AND ProductSubCategoryID = 1)
      OR ListPrice BETWEEN 1000 AND 2000
ORDER BY ProductID

--Query 16
SELECT Name, ISNULL(Color, 'Unknown') AS Color, ListPrice
FROM Production.Product