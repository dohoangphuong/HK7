USE AdventureWorks2012
GO

--Query 1
SELECT COUNT(*)
FROM Production.Product

--Query 2
SELECT COUNT(ProductSubcategoryID) AS HasSubCategoryID
FROM Production.Product
WHERE ProductSubcategoryID IS NOT NULL

--Query 3
SELECT ProductSubcategoryID, COUNT(ProductID) AS CountedProducts
FROM Production.Product
GROUP BY ProductSubcategoryID

--Query 4
SELECT COUNT(ProductID) AS CountedProducts
FROM Production.Product
WHERE ProductSubcategoryID IS NULL
GROUP BY ProductSubcategoryID

--Query 5
SELECT ProductID, SUM(Quantity) AS  TheSum
FROM Production.ProductInventory 
GROUP BY ProductID

--Query 6
SELECT ProductID, SUM(Quantity) AS  TheSum
FROM Production.ProductInventory 
WHERE LocationID =40 AND Quantity<100
GROUP BY ProductID

--Query 7
SELECT Shelf, ProductID, SUM(Quantity) AS  TheSum
FROM Production.ProductInventory 
WHERE LocationID =40 AND Quantity<100
GROUP BY ProductID, Shelf

--Query 8
SELECT AVG(Quantity) AS THEAVG
FROM Production.ProductInventory 
WHERE LocationID =10

--Query 9
SELECT COUNT(ProductID), Shelf, AVG(Quantity) AS THEAVG
FROM Production.ProductInventory
WHERE Shelf != 'N/A' 
GROUP BY  Shelf,ProductID

--Query 10
SELECT Color, Class, AVG(ListPrice) AS AVG, COUNT(ProductID) AS THESUM
FROM Production.Product
 WHERE (Class IS NOT NULL AND Color IS  NOT NULL)
GROUP  BY GROUPING SETS (Color, Class)

--Query 11
SELECT ProductSubcategoryID,COUNT(Name) as Counted
FROM Production.Product
GROUP BY ROLLUP (ProductSubcategoryID)