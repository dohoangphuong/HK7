﻿-- Exercise 1: Design a table
USE master
GO

IF EXISTS (SELECT * FROM sys.databases WHERE Name LIKE 'Trainee')
DROP DATABASE Trainee
GO

CREATE DATABASE Trainee
GO

USE Trainee
GO

SET DATEFORMAT dmy
GO
-- Q1
CREATE TABLE Trainee
(
TraineeID	int		IDENTITY(1,1)	PRIMARY KEY,
Full_Name	nvarchar(50),
Birth_Date	datetime,
Gender	varchar(10) NOT NULL CHECK (Gender IN ('male', 'female', 'unknown')),
ET_IQ	tinyint CHECK (ET_IQ >= 0 AND ET_IQ <= 20),
ET_Gmath	tinyint CHECK (ET_Gmath >= 0 AND ET_Gmath <=20),
ET_English	tinyint CHECK (ET_English >= 0 AND ET_English <= 50),
Training_Class	varchar(50),
Evaluation_Notes	nvarchar(120)
)

GO
-- Q2
ALTER TABLE Trainee
ADD Fsoft_Account varchar(20) NOT NULL	UNIQUE

GO
-- Q3
INSERT INTO Trainee (Full_Name, Birth_Date, Gender, ET_IQ, ET_Gmath, ET_English, Training_Class, Evaluation_Notes, Fsoft_Account) VALUES
					(N'Nguyễn Thái Bảo', '14/2/1993', 'male', 15, 7, 30, 'NET', '', 'acc01'),
					(N'Nguyễn Đăng Khoa', '12/1/1993', 'male', 19, 12, 25, 'JAVA', '', 'acc02'),
					(N'Bùi Khánh Linh', '10/10/1993', 'female', 5, 18, 35, 'NET', '', 'acc03'),
					(N'Trần Minh Thu', '1/6/1993', 'female', 20, 19, 17, 'TEST', '', 'acc04'),
					(N'Nguyễn Huy Trúc', '3/8/1993', 'male', 15, 10, 39, 'CPP', '', 'acc05'),
					(N'Lê Huy Hiếu', '7/2/1993', 'unknown', 12, 9, 2, 'JAVA', '', 'acc06'),
					(N'Võ Ánh Nhi', '4/1/1993', 'unknown', 9, 7, 15, 'TEST', '', 'acc07'),
					(N'Vũ Tiến Đạt', '5/2/1993', 'male', 5, 12, 34, 'CPP', '', 'acc08'),
					(N'Trần Anh Duy', '4/9/1993', 'male', 14, 7, 27, 'TEST', '', 'acc09'),
					(N'Lê Minh Hiếu', '9/12/1993', 'unknown', 17, 20, 25, 'NET', '', 'acc10');

GO
-- Q4
CREATE VIEW [ET-passed Trainees List] AS
	SELECT *
	FROM Trainee
	WHERE ET_IQ + ET_Gmath >= 20 AND ET_IQ >=8 AND ET_Gmath >= 8 AND ET_English >= 18

SELECT * FROM [ET-passed Trainees List]

GO
-- Q5
SELECT Full_Name, Birth_Date, Gender, DATEDIFF(year, Trainee.Birth_Date, GETDATE()) AS Age
FROM Trainee
WHERE LEN(Full_Name)	IN(SELECT TOP 1 LEN(Full_Name) AS MaxLength
						   FROM Trainee
						   ORDER BY LEN(Full_Name) DESC)