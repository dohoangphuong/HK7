-- Exercise 2: Querying and Filtering Data
USE AdventureWorks2008
GO

GO
-- Query 1
SELECT ProductID, Name, Color, ListPrice
FROM Production.Product

GO
-- Query 2
SELECT ProductID, Name, Color, ListPrice
FROM Production.Product
WHERE ListPrice > 0

GO
-- Query 3
SELECT ProductID, Name, Color, ListPrice
FROM Production.Product
WHERE Color is NULL

GO
-- Query 4
SELECT ProductID, Name, Color, ListPrice
FROM Production.Product
WHERE Color IS NOT NULL

GO
-- Query 5
SELECT ProductID, Name, Color, ListPrice
FROM Production.Product
WHERE Color IS NOT NULL AND ListPrice > 0

GO
-- Query 6
SELECT Name + ' : ' + Color AS 'Name And Color'
FROM Production.Product
WHERE Color IS NOT NULL

GO
-- Query 7
SELECT 'NAME: ' + Name + ' -- ' + 'COLOR: ' + Color AS 'Name And Color'
FROM Production.Product
WHERE Color IS NOT NULL

GO 
-- Query 8
SELECT ProductID, Name
FROM Production.Product
WHERE ProductID BETWEEN 400 AND 500

GO 
-- Query 9
SELECT ProductID, Name, Color
FROM Production.Product
WHERE Color = 'black' OR Color = ' blue'

GO
-- Query 10
SELECT Name, ListPrice
FROM Production.Product
WHERE Name LIKE 's%'
ORDER BY Name ASC

GO
-- Query 11
SELECT Name, ListPrice
FROM Production.Product
WHERE Name LIKE 's%' OR Name LIKE 'a%'
ORDER BY Name ASC

GO
-- Query 12
SELECT Name, ListPrice
FROM Production.Product
WHERE Name LIKE 'SPO%' AND Name NOT LIKE 'SPOK%'

GO
-- Query 13
SELECT DISTINCT Color
FROM Production.Product

GO
-- Query 14
SELECT DISTINCT ProductSubcategoryID, Color
FROM Production.Product
WHERE ProductSubcategoryID IS NOT NULL AND Color IS NOT NULL
ORDER BY ProductSubcategoryID ASC

GO 
-- Query 15
SELECT ProductSubCategoryID
      , LEFT([Name],35) AS [Name]
      , Color, ListPrice
FROM Production.Product
WHERE (Color IN ('Red','Black') 
		AND ProductSubcategoryID = 1)
      OR ListPrice BETWEEN 1000 AND 2000 
ORDER BY ProductID

GO
-- Query 16
SELECT Name, ISNULL(Color, 'Unknown') Color, ListPrice
FROM Production.Product
