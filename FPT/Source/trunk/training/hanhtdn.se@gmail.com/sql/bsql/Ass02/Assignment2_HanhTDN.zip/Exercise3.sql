-- Exercise 3: Grouping and Summarizing Data
USE AdventureWorks2008
GO

GO
-- Query 1
SELECT COUNT(*)
FROM Production.Product

GO
-- Query 2
SELECT COUNT(ProductSubcategoryID) AS HasSubCategoryID
FROM Production.Product
WHERE ProductSubcategoryID IS NOT NULL

GO
-- Query 3
SELECT ProductSubcategoryID, COUNT(ProductID) AS CountedProducts
FROM Production.Product
GROUP BY ProductSubcategoryID

GO
-- Query 4
-- WHERE clause
SELECT COUNT(ProductID)
FROM Production.Product
WHERE ProductSubcategoryID IS NULL
GROUP BY ProductSubcategoryID

-- without WHERE clause
SELECT TOP 1 COUNT(ProductID)
FROM Production.Product
GROUP BY ProductSubcategoryID

GO
-- Query 5
SELECT ProductID, SUM(Quantity) AS TheSum
FROM Production.ProductInventory
GROUP BY ProductID

GO
-- Query 6
SELECT ProductID, SUM(Quantity) AS TheSum
FROM Production.ProductInventory
WHERE LocationID = 40 AND Quantity < 100
GROUP BY ProductID

GO
-- Query 7
SELECT Shelf, ProductID, SUM(Quantity) AS TheSum
FROM Production.ProductInventory
WHERE LocationID = 40 AND Quantity < 100
GROUP BY Shelf, ProductID

GO
-- Query 8
SELECT AVG(Quantity) AS TheAvg
FROM Production.ProductInventory
WHERE LocationID = 10

GO
-- Query 9


GO
-- Query 10
SELECT Color, Class, COUNT(ProductID) AS TheCountAvg, AVG(ListPrice) AS Price
FROM Production.Product
WHERE (Class IS NOT NULL AND Color IS  NOT NULL)
GROUP  BY GROUPING SETS (Color, Class)

GO
-- Query 11
SELECT ProductSubcategoryID, COUNT(Name) as Counted
FROM Production.Product
GROUP BY ROLLUP (ProductSubcategoryID)