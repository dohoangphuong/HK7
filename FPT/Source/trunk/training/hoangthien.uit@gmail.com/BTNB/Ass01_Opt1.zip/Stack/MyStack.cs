﻿using System.Collections.Generic;

namespace Stack
{
    class MyStack
    {
        private List<object> stackValues;

        public MyStack()
        {
            stackValues = new List<object>();
        }

        /// <summary>
        /// Pop a value out from the stack
        /// </summary>
        /// <param name="obj"></param>
        public void Push(object obj)
        {
            if (obj != null)
            {
                stackValues.Add(obj);
            }
        }

        /// <summary>
        /// Pop a value out from the stack
        /// </summary>
        /// <returns></returns>
        public object Pop()
        {
            if (stackValues.Count != 0)
            {
                object objTemp = stackValues[stackValues.Count - 1];
                if (stackValues.Remove(objTemp))
                {
                    return objTemp;
                }
            }

            return null;
        }

        /// <summary>
        /// Get a value from the stack
        /// </summary>
        /// <returns></returns>
        public object Get()
        {
            if (stackValues.Count != 0)
            {
                return stackValues[stackValues.Count - 1];
            }
            return null;
        }
    }
}
