﻿using System;

namespace Stack
{
    class Program
    {
        static void Main(string[] args)
        {
            MyStack demoStack = new MyStack();
            demoStack.Push(0);
            demoStack.Push(1);
            demoStack.Push(2);
            Console.WriteLine(demoStack.Pop());
            Console.WriteLine(demoStack.Pop());
            Console.WriteLine(demoStack.Get());
            Console.ReadLine();
        }
    }
}
