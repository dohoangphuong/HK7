﻿namespace ManageBees
{
    class Drone:Bee
    {
        public override void Damage(int dame)
        {
            if (dead) //If it dead return;
                return;

            //Drone has health below 50%, is dead.
            dead = health - dame < health * 0.5;

            //Subtract health with attacked damage, 0 if damage > health
            health = (dame < health) ? (health - dame) : 0;
        }

        public override void Show()
        {
            //Show status of bee
            System.Console.WriteLine("-Drone | Heath: {0}%, Dead: {1}", health, dead);
        }
    }
}
