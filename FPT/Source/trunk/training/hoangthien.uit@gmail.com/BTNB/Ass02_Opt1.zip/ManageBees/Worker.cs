﻿namespace ManageBees
{
    class Worker:Bee
    {
        public override void Damage(int dame)
        {
            if (dead) //If it dead return;
                return;

            //Worker has health below 70%, is dead.
            dead = health - dame < health * 0.7;

            //Subtract health with attacked damage, 0 if damage > health
            health = (dame < health) ? (health - dame) : 0;
        }

        public override void Show()
        {
            //Show status of bee
            System.Console.WriteLine("-Worker | Heath: {0}%, Dead: {1}", health, dead);
        }
    }
}
