﻿USE AdventureWorks2008
GO

--Exercise 1:Design a table 
--Q1
SET DATEFORMAT dmy
CREATE TABLE TRAINEE
(
	TraineeID	int		IDENTITY	primary key,
	Full_Name	nvarchar(50),
	Birth_Date	datetime,
	Gender		varchar(10) not null CHECK (Gender in('male','female','unknown')),
	ET_IQ		Tinyint CHECK (ET_IQ >= 0 AND ET_IQ <= 20),
	ET_Gmath	Tinyint CHECK (ET_Gmath >= 0 AND ET_Gmath <= 20),
	ET_English	tinyint CHECK (ET_English >= 0 AND ET_English <= 50),
	Training_Class		varchar(50),
	Evaluation_Notes	nvarchar(100)
)


--Q2

ALTER TABLE TRAINEE
ADD Fsoft_Account varchar(20) not null


--Q3
INSERT INTO TRAINEE (Full_Name, Birth_Date, Gender, ET_IQ, ET_Gmath, ET_English, Training_Class, Evaluation_Notes, Fsoft_Account) VALUES  
					(N'Nguyễn Văn A',		1/1/1994,	'male',		10,		5,		 10,		'ABC',		'',				'account01'),
					(N'Nguyễn Văn B',		2/3/1994,	'male',		15,		15,		 15,		'CDE',		'',				'account02'),
					(N'Nguyễn Văn C',		3/1/1994,	'female',	15,		15,		 15,		'FGH',		'',				'account03'),
					(N'Nguyễn Văn D',		4/5/1994,	'female',	12,		12,		 12,		'AAA',		'',				'account04'),
					(N'Nguyễn Văn E',	5/1/1994,	'unknown',	5,		17,		 32,		'BBB',		'',				'account05'),
					(N'Trần Văn A',	6/7/1994,	'unknown',	17,		17,		 40,		'CCC',		'',				'account06'),
					(N'Trần Văn B',	7/1/1994,	'unknown',	17,		17,		 10,		'DDD',		'',				'account07'),
					(N'Trần Văn C',	8/9/1994,	'female',	15,		15,		 15,		'EEE',		'',				'account08'),
					(N'Trần Văn D',	9/1/1994,	'unknown',	5,		15,		 15,		'FFF',		'',				'account09'),
					(N'Trần Văn E',	10/1/1994,	'female',	15,		15,		 15,		'EEE',		'',				'account10');


--Q4
CREATE VIEW [ET-passed trainees List] AS
SELECT  *
FROM TRAINEE
WHERE ET_IQ + ET_Gmath>=20 AND ET_IQ>=8 AND ET_Gmath>=8 AND ET_English>=18

SELECT * FROM [ET-passed trainees List]
--Q5--

SELECT *, DATEDIFF(year, TRAINEE.Birth_Date, GETDATE())	AS Age
FROM TRAINEE
WHERE LEN(Full_Name)	IN(	SELECT TOP 1 LEN(Full_Name) AS MaxLength
							FROM TRAINEE
							ORDER BY LEN(Full_Name) DESC)


--Exercise 2: Querying and Filtering Data
--Query 1
SELECT A.ProductID, A.Name, A.Color, A.ListPrice
FROM Production.Product A

--Query 2
SELECT A.ProductID, A.Name, A.Color, A.ListPrice
FROM Production.Product A
WHERE A.ListPrice <> 0

--Query 3
SELECT A.ProductID, A.Name, A.Color, A.ListPrice
FROM Production.Product A
WHERE A.Color is NULL

--Query 4
SELECT A.ProductID, A.Name, A.Color, A.ListPrice
FROM Production.Product A
WHERE A.Color is not NULL

--Query 5
SELECT A.ProductID, A.Name, A.Color, A.ListPrice
FROM Production.Product A
WHERE A.Color is not NULL AND A.ListPrice != 0

--Query 6
SELECT 'Name And Color' = A.Name + ' : ' + A.Color
FROM Production.Product A 
WHERE A.Color is not null


--Query 7
SELECT 'Name And Color' ='NAME: ' + A.Name +'  --  ' + 'COLOR: ' + A.Color
FROM Production.Product A 
WHERE A.Color is not null

--Query 8
SELECT A.ProductID, A.NAME
FROM Production.Product A 
WHERE A.ProductID BETWEEN 400 and 500

--Query 9
SELECT A.ProductID, A.NAME, A.Color
FROM Production.Product A
WHERE A.Color= 'black' or A.Color= 'blue' 

--Query 10
SELECT A.Name, A.ListPrice
FROM Production.Product A
WHERE A.Name LIKE 's%' 
ORDER BY A.Name ASC

--Query 11
SELECT A.Name, A.ListPrice
FROM Production.Product A
WHERE A.Name LIKE 'a%' or A.Name LIKE 's%'
ORDER BY A.Name ASC

--Query 12
SELECT A.Name 
FROM Production.Product A
WHERE A.Name LIKE 'SPO%' and A.Name not in (	SELECT A.Name 
												FROM Production.Product A
												WHERE A.Name LIKE 'SPOK%') 
--Query 13
SELECT distinct A.Color
FROM Production.Product A

--Query 14
SELECT distinct A.ProductSubcategoryID, A.Color
FROM Production.Product A
WHERE (A.Color IS NOT NULL) AND (A.ProductSubcategoryID IS NOT NULL)

--Query 15
SELECT ProductSubCategoryID
      , LEFT([Name],35) AS [Name]
      , Color, ListPrice
FROM Production.Product
WHERE (Color IN ('Red','Black')
       AND ProductSubCategoryID = 1)
      OR ListPrice BETWEEN 1000 AND 2000
ORDER BY ProductID

--Query 16
SELECT A.Name, A.Color, A.ListPrice
FROM Production.Product A
WHERE A.Color IS NULL AND A.Color = REPLACE('NULL', 'NULL', 'Unknown') 


--Exercise 3: Grouping and Summarizing Data 
--Query 1
SELECT COUNT(A.ProductID)
FROM Production.Product A

--Query 2
SELECT 'HasSubCategoryID' = COUNT(A.ProductID)
FROM Production.Product A
WHERE A.ProductSubcategoryID IS NOT NULL

--Query 3
SELECT A.ProductSubcategoryID, 'CountedProducts' = COUNT(A.ProductID)
FROM Production.Product A
GROUP BY A.ProductSubcategoryID