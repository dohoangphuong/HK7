﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStack
{
    class MyStack
    {
        private List<Object> MyStackValues;

        public MyStack()
        {
            MyStackValues = new List<object>();
        }

        public void Push(Object obj)
        {
            if (MyStackValues.Count == 0)
                MyStackValues.Add(obj);
            else
                MyStackValues.Insert(0, obj);
        }

        public void Pop()
        {
            if (MyStackValues.Count >= 1)
            {
                MyStackValues.RemoveAt(0);
            }
        }

        public object Get(int position)
        {
            if (position >= 0 && position <= (MyStackValues.Count - 1))
                return MyStackValues[position];
            else
                if (MyStackValues.Count < 0)
                    return -1;
                else
                    if (position > MyStackValues.Count - 1)
                        return -2;
            return -3;
        }
    }
}
