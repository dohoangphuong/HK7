﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStack
{
    class Program
    {
        static void Main(string[] args)
        {
            MyStack myStack = new MyStack();
            myStack.Push(5);
            myStack.Push(4);
            myStack.Push(3);
            myStack.Push(2);
            myStack.Push(1);

            myStack.Pop();

            System.Console.WriteLine(myStack.Get(0).ToString());
            System.Console.WriteLine(myStack.Get(-6).ToString());

        }
    }
}
