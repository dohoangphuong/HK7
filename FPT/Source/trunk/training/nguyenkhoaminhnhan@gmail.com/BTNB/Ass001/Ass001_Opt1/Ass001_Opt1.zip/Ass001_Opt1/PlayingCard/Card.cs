﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlayingCard
{
    class PlayingCard
    {
        int rank, suit;

        public PlayingCard()
        {
            this.rank = 0;
            this.suit = 0;
        }

        public PlayingCard(int rank, int suit)
        {
            this.rank = rank;
            this.suit = suit;
        }

        public void printPlayingCard()
        {
            String[] ranks = { "temp", "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };
            String[] suits = { "Spades", "Clubs", "Diamonds", "Hearts" };
            Console.WriteLine(ranks[this.rank] + "\t" + suits[this.suit]);
        }
    }
}
