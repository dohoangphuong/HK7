﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlayingCard
{
    class DeckCard
    {
        PlayingCard[] cards;

        public DeckCard()
        {
            cards = new PlayingCard[52];

            int index = 0;
            for (int rank = 1; rank <= 13; rank++)
            {
                for (int suit = 0; suit <= 3; suit++)
                {
                    cards[index] = new PlayingCard(rank, suit);
                    index++;
                }
            }
        }

        public void printDeckCard()
        {
            for (int i = 0; i < cards.Length; i++)
            {
                cards[i].printPlayingCard();
                if ((i + 1)% 4 == 0)
                {
                    System.Console.WriteLine("\n");
                }
            }
        }
    }
}
