﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASS01_02
{
    class Card
    {
        private string cardName;  //Card Name : nameRank - nameSuit
       
        /*14 Card Rank:
         * 0. Joker
         * 1. Ace
         * 2. Two
         * 3. Three -> 10. Ten
         * 11. Jack
         * 12. Queen
         * 13. King
         */
        private int cardRank; //Rank card
        
        /* 4 Common Card Suit:
         * 1. Spade
         * 2. Club
         * 3. Diamond
         * 4. Heart
         */
        private int cardSuit; // Suit card

        //Create a new Card with rank, suit, name
        public Card(int rank, int suit, string name) {
            cardRank = rank;
            cardSuit = suit;
            cardName = name;
        }
        
        //Show name of card
        public void cardShow()
        {
            System.Console.WriteLine(cardName);
        }
    }
}
