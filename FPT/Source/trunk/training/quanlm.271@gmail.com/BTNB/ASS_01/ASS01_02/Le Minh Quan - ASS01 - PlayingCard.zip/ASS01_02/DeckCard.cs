﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASS01_02
{
    class DeckCard
    {
        private List<Card> cardList;

        private string[] nameRankList = new string[] {
            "Joker","Ace","Two","Three",
            "Four","Five","Six","Seven","Eight",
            "Nine","Ten","Jack","Queen","King"};

        private string[] nameSuitList = new string[] {"","Spade","Club","Diamond","Heart"}; 

        public DeckCard() 
        {
            cardList = new List<Card>();
            cardList.Add(new Card(0, 0, nameRankList[0] + "-" + nameSuitList[0]));
            cardList.Add(new Card(0, 0, nameRankList[0] + "-" + nameSuitList[0]));

            for (int i = 1; i <= 13; i++)
                for (int j = 1; j <= 4; j++)  
                    cardList.Add(new Card(i, j, nameRankList[i] + "-" + nameSuitList[j]));


        }
        public void CreateByPlayer(int players)
        {
            
        }
        public void ShowDeck()
        {
            foreach (Card c in cardList)
                c.cardShow();
        }
    }
}
