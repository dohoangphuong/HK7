﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASS01_02
{
    class Program
    {
        static void Main(string[] args)
        {
            DeckCard deckcard = new DeckCard();
            deckcard.ShowDeck();
            System.Console.Read();
        }
    }
}
