﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASS02
{
    abstract class Bee
    {
        protected float health = 100; //Health
        protected bool dead = false;  //Status, default value is alive or dead = false

        abstract public void Damage(int dam);
        abstract public void Show();
    }
}
