﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASS02
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create random parametter
            Random r = new Random();

            //List contains bees
            List<Bee> beeList = new List<Bee>(); 
            
            //Number of bee in list
            int totalBee = 30; 

            //This is call a respective function 
            int function;
            do
            {
                System.Console.WriteLine("\n1.Create bee list \n2.Attack bees  \nChoose function:");
                function = int.Parse(System.Console.ReadLine()); //Read input value
                if (function == 1) //go to Create
                {
                    //Create function-----------------------------
                    System.Console.WriteLine("Create....");

                    //Clear all bee list to create a new elements
                    beeList.Clear(); 

                    //This is identify to create a type of bee;
                    int beeType;

                    //temp total to loop
                    int total = totalBee;
                    while (total-- > 0)
                    {
                        beeType = r.Next(0, 3); //Random type of bee
                        switch (beeType)
                        {
                            case 0: //Create a new Worker
                                Worker w = new Worker();
                                beeList.Add(w);
                                break;
                            case 1: //Create a new Queen
                                Queen q = new Queen();
                                beeList.Add(q);
                                break;
                            case 2: //Create a new Drone
                                Drone d = new Drone();
                                beeList.Add(d);
                                break;
                            default:
                                break;
                        }
                    }

                    //Show result for each bee in list
                    System.Console.WriteLine("Show....");
                    foreach (Bee b in beeList)
                        b.Show();
                    //End Create-----------------------------------
                }
                else if(function == 2) //go to Attack
                {
                    //Attack function -------------------------------
                    System.Console.WriteLine("Attack....");
                    int dam; //Attacked damage 
                    foreach (Bee b in beeList)
                    {
                        dam = r.Next(0, 81); //Random damage from 0 to 80
                        b.Damage(dam);
                    }

                    //Show result for each bee in list
                    System.Console.WriteLine("Show....");
                    foreach (Bee b in beeList)
                        b.Show();
                    //End Attack ------------------------------------
                }
            } while (function != -1); //end loop if input value = -1

        }
    }
}
