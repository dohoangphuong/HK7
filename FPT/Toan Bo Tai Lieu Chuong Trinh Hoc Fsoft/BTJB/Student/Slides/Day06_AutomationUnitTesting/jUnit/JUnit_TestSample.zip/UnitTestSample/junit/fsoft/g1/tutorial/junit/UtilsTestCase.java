package fsoft.g1.tutorial.junit;

import junit.framework.TestCase;

public class UtilsTestCase extends TestCase {
	// set of test data for this Utils.max(int[]) method
	private int[][] maxData = {
		{1, 2, 3},
		{1, 1, 1, 1, 1, 1},
		{7, 6, 5, 4, 3, 2, 1},
		{},
		{-1}
	};
	
	// set of results for Utils.max(int[]) method
	private int[] maxResult = {3, 1, 7, 0, -1};
	
	// set of test data for Utils.min(int[]) method
	private int[][] minData = maxData;
	
	// set of results for Utils.min(int[]) method
	private int[] minResult = {1, 1, 1, 0, -1};
	
	
	private static String[] operatorData1 = {"1",	"0", 	"1000",	"9999", 	"-1", 	"-1",	"-99",	"0"};
	private static String[] operatorData2 = {"1",	"1111",	"1", 	"999999",	"++1-",	"1", 	"-0", 	"-1"};
	private static Long[] sumResult = {new Long(2), new Long(1111), new Long(1001), new Long(1009998), null, new Long(0), new Long(-99), new Long(-1) };
	private static Long[] subResult = {new Long(0), new Long(-1111), new Long(999), new Long(-990000), null, new Long(-2), new Long(-99), new Long(1)};
	private static Long[] mulResult = {new Long(1), new Long(0), new Long(1000), new Long(9998990001L), null, new Long(-1), new Long(0), new Long(0) };
	private static Long[] divResult = {new Long(1), new Long(0), new Long(1000), new Long(0), null, new Long(-1), null, new Long(0) };
	private static Long[] molResult = {new Long(0), new Long(0), new Long(0), new Long(9999), null, new Long(0), null, new Long(0) };

	
	/**
	 * Test {@link Utils#max(int[])} method
	 * 
	 * @author sandman
	 */
	public void testMax() {
		for ( int i = 0; i < maxData.length; i++ ) {
			assertEquals("Fail on data set number " + i + ".", Utils.max(maxData[i]), maxResult[i] );
		} // end for
	} // end of testMax()

	
	/**
	 * Test {@link Utils#min(int[])} method
	 * 
	 * @author sandman
	 */
	public void testMin() {
		for ( int i = 0; i < minData.length; i++ ) {
			assertEquals("Fail on data set number " + i + ".", Utils.min(minData[i]), minResult[i] );
		} //
	} // end of testMin()
	
	
	/**
	 * Test {@link Utils#sum(String, String)} method
	 * 
	 * @author sandman
	 */
	public void testSum() {
		Long result;
		for ( int i = 0; i < operatorData1.length; i++ ) {
			try {
				result = new Long( Utils.sum(operatorData1[i], operatorData2[i]) );
			} catch ( Exception e ) {
				result = null;
			}
			
			assertEquals("Fail on set number " + i + ". ", result, sumResult[i] );
		} // end for
	} // end of testSum()
	
	
	/**
	 * Test {@link Utils#sub(String, String)} method
	 * 
	 * @author sandman
	 */
	public void testSubtract() {
		Long result;
		for ( int i = 0; i < operatorData1.length; i++ ) {
			try {
				result = new Long( Utils.substract(operatorData1[i], operatorData2[i]) );
			} catch ( Exception e ) {
				result = null;
			}
			
			assertEquals("Fail on set number " + i + ". ", result, subResult[i] );
		} // end for
	} // end of testSubtract()
	
	
	/**
	 * Test {@link Utils#multi(String, String)} method
	 * 
	 * @author sandman
	 */
	public void testMulti() {
		Long result;
		for ( int i = 0; i < operatorData1.length; i++ ) {
			try {
				result = new Long( Utils.multi(operatorData1[i], operatorData2[i]) );
			} catch ( Exception e ) {
				result = null;
			}
			
			assertEquals("Fail on set number " + i + ". ", result, mulResult[i] );
		} // end for
	} // end of testMulti()
	
	
	/**
	 * Test {@link Utils#divide(String, String)} method
	 * 
	 * @author sandman
	 */
	public void testDivide() {
		Long result;
		for ( int i = 0; i < operatorData1.length; i++ ) {
			try {
				result = new Long( Utils.divide(operatorData1[i], operatorData2[i]) );
			} catch ( Exception e ) {
				result = null;
			}
			
			assertEquals("Fail on set number " + i + ". ", result, divResult[i] );
		} // end for
	} // end of testDivide()
	
	
	/**
	 * Test {@link Utils#module(String, String)} method
	 * 
	 * @author sandman
	 */
	public void testModule() {
		Long result;
		for ( int i = 0; i < operatorData1.length; i++ ) {
			try {
				result = new Long( Utils.module(operatorData1[i], operatorData2[i]) );
			} catch ( Exception e ) {
				result = null;
			}
			
			assertEquals("Fail on set number " + i + ". ", result, molResult[i] );
		} // end for
	} // end of testModule()
	
	public static void main( String[] args ) {
	}
}
