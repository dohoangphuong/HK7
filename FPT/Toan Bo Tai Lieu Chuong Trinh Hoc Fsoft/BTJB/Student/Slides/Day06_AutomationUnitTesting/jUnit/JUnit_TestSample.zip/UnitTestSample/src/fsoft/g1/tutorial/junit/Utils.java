package fsoft.g1.tutorial.junit;

/**
 * @author sandman
 *
 */
public class Utils {
	/**
	 * Find the extreme value of an integer array
	 * 
	 * @author sandman
	 * @param a		integer array
	 * @param sign	must be -1 or +1
	 * @return		the extreme value of the array, this value will be min or max depends on sign value
	 */
	private static int extreme( int[] a, int sign ) {
		// check length of a
		if ( a.length == 0 ) {
			return 0;
		}
		
		// find max
		int max = a[0]*sign;
		int index = 0;
		int current = 0;
		for ( int i = 0; i < a.length; i++ ) {
			current = a[i]*sign;
			
			if ( current > max ) {
				max = current;
				index = i;
			} // end if
		} // end for
		
		return a[index];
	} // end max( int[] )
	
	
	/**
	 * Find the max value of input array
	 * 
	 * @author sandman
	 * @param a	int array
	 * @return	the max value
	 */
	public static int max( int[] a ) {
		return extreme( a, 1 );
	}
	
	
	/**
	 * Find the min value of input array
	 * 
	 * @author sandman
	 * @param a	int array
	 * @return	the min value
	 */
	public static int min( int[] a ) {
		return extreme( a, -1 );
	}
	
	
	/**
	 * Calculate sum of two numeric string
	 * @param int1	the first number
	 * @param int2	the second number
	 * @return		the sum
	 */
	public static long sum( String int1, String int2 ) {
		try {
			long num1 = Long.parseLong( int1 );
			long num2 = Long.parseLong( int2 );
			
			return num1 + num2;
		} catch ( NumberFormatException e ) {
			throw new IllegalArgumentException();
		}
	} // end of add( String, String )
	
	
	/**
	 * Calculate subtraction of two numeric string
	 * @param int1	the first number
	 * @param int2	the second number
	 * @return		the subtraction
	 */
	public static long substract( String int1, String int2 ) {
		try {
			long num1 = Long.parseLong( int1 );
			long num2 = Long.parseLong( int2 );
			
			return num1 - num2;
		} catch ( NumberFormatException e ) {
			throw new IllegalArgumentException();
		}
	} // end of subtract( String, String )
	
	
	/**
	 * Multiply two numeric string
	 * @param int1	the first number
	 * @param int2	the second number
	 * @return		the result
	 */
	public static long multi( String int1, String int2 ) {
		try {
			long num1 = Long.parseLong( int1 );
			long num2 = Long.parseLong( int2 );
			
			return num1*num2;
		} catch ( NumberFormatException e ) {
			throw new IllegalArgumentException();
		}
	} // end of multi( String, String )
	
	
	/**
	 * 
	 * @param int1	the first number
	 * @param int2	the second number
	 * @return		the c
	 */
	public static long divide( String int1, String int2 ) {
		try {
			long num1 = Long.parseLong( int1 );
			long num2 = Long.parseLong( int2 );
			
			return num1/num2;
		} catch ( NumberFormatException e ) {
			throw new IllegalArgumentException();
		}
	} // end of divide( String, String )
	
	
	/**
	 * 
	 * @param int1	the first number
	 * @param int2	the second number
	 * @return		the module of first number to second number
	 */
	public static long module( String int1, String int2 ) {
		try {
			long num1 = Long.parseLong( int1 );
			long num2 = Long.parseLong( int2 );
			
			return num1 % num2;
		} catch ( NumberFormatException e ) {
			throw new IllegalArgumentException();
		}
	} // end of module( String, String )
}